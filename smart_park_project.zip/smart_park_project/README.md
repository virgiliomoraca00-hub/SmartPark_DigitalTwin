# Smart Park — Digital Twin Platform

Piattaforma IoT che simula il monitoraggio ambientale di un parco urbano tramite **Digital Twin**. Tre sensori virtuali pubblicano dati in tempo reale su un bus MQTT; da lì l'infrastruttura li instrada automaticamente verso un motore di Digital Twin (Eclipse Ditto) e un database time-series (InfluxDB), visualizzati su una dashboard Grafana.

---

## Flusso dei dati

```
sensor_simulator.py
        │
        ▼
  MQTT Broker (Mosquitto :1883)
        │
   ┌────┴──────────────────────┐
   ▼                           ▼
Telegraf                  Eclipse Ditto
(bridge MQTT→InfluxDB)    (Digital Twin Engine)
   │                           │
   ▼                           ▼
InfluxDB                   MongoDB
(serie storica)            (stato attuale dei Twin)
   │
   ▼
Grafana
(dashboard real-time)
```

**Lo script Python scrive esclusivamente su MQTT.** Il resto della pipeline è completamente automatico:

- **Telegraf** è sottoscritto ai topic MQTT e scrive ogni lettura in InfluxDB
- **Eclipse Ditto** riceve i messaggi MQTT tramite il servizio Connectivity, li trasforma con uno script JavaScript e aggiorna lo stato dei Digital Twin
- **Grafana** interroga InfluxDB ogni 5 secondi e aggiorna la dashboard

---

## Componenti

### sensor_simulator.py

Script Python che simula 3 sensori ambientali nel parco. Ogni 5 secondi genera dati realistici con variazioni sinusoidali (per simulare cicli giornalieri) più rumore casuale, e li pubblica su MQTT.

**Sensori:**

| ID | Zona | Coordinate |
|----|------|------------|
| `sensor-entrance` | Ingresso Principale | 38.1157, 13.3615 |
| `sensor-lake` | Area Lago | 38.1162, 13.3620 |
| `sensor-playground` | Area Giochi | 38.1150, 13.3608 |

**Misure generate da ogni sensore:**

| Campo | Range | Unità |
|-------|-------|-------|
| `temperature` | 15 – 28 | °C |
| `humidity` | 40 – 80 | % |
| `air_quality` | 400 – 900 | ppm CO₂ |
| `motion` | 0 – 50 | persone rilevate |
| `noise` | 30 – 80 | dB |
| `anomaly` | true/false | spike CO₂ (prob. 2%) |

**Topic MQTT pubblicati:**
```
smart-park/sensor-entrance/telemetry
smart-park/sensor-lake/telemetry
smart-park/sensor-playground/telemetry
```

**Payload esempio:**
```json
{
  "sensor_id":   "sensor-entrance",
  "timestamp":   "2026-03-12T17:00:00+00:00",
  "temperature": 21.5,
  "humidity":    58.4,
  "air_quality": 720.3,
  "motion":      12,
  "noise":       55.1,
  "anomaly":     false
}
```

---

### test_stack.py

Script Python che testa uno per uno tutti i componenti dello stack e restituisce un riepilogo `PASS` / `FAIL`. Esegue:

1. Verifica connettività TCP su tutte le porte
2. Creazione, lettura, aggiornamento e cancellazione di una Policy e di un Thing su Ditto
3. Publish/Subscribe MQTT
4. Scrittura e query su InfluxDB
5. API check su RabbitMQ
6. Health check su Grafana

**Uso:**
```bash
source smart_park_env/bin/activate
python3 scripts/test_stack.py
```

---

### Eclipse Mosquitto — MQTT Broker

**Porta:** 1883 (MQTT) | 9001 (WebSocket)

Il broker MQTT è il punto centrale di ingresso dati. Gestisce la comunicazione publish/subscribe: il simulatore pubblica i messaggi, Telegraf e Ditto li consumano autonomamente. Configurato senza autenticazione (modalità sviluppo).

**Configurazione rilevante (`mosquitto/config/mosquitto.conf`):**
- Listener MQTT su porta 1883
- Listener WebSocket su porta 9001
- Connessioni anonime permesse
- Persistenza messaggi attiva su `/mosquitto/data/`

---

### Telegraf — Bridge MQTT → InfluxDB

Telegraf si sottoscrive ai topic `smart-park/+/telemetry` su Mosquitto, parsa il payload JSON e scrive ogni lettura in InfluxDB. È la componente che alimenta Grafana con la serie storica dei dati.

**Configurazione (`telegraf/telegraf.conf`):**
- Input: MQTT Consumer (topic `smart-park/+/telemetry`, QoS 1)
- Parsing: JSON — il campo `sensor_id` diventa tag per query efficienti
- Timestamp: letto dal campo `timestamp` del payload
- Measurement: `sensor_reading`
- Output: InfluxDB v2 (bucket `sensor-data`, org `smart-park`)
- Intervallo raccolta: 5 secondi

---

### InfluxDB — Time-Series Database

**Porta:** 8086 | **UI:** http://localhost:8086

Database ottimizzato per serie temporali. Conserva tutta la storia delle misurazioni dei sensori. Usa il linguaggio di query **Flux**.

| Parametro | Valore |
|-----------|--------|
| Organization | `smart-park` |
| Bucket | `sensor-data` |
| Admin token | `smart-park-token-12345` |
| Measurement | `sensor_reading` |
| Tag | `sensor_id` |
| Fields | `temperature`, `humidity`, `air_quality`, `motion`, `noise`, `anomaly` |

**Esempio query Flux:**
```flux
from(bucket: "sensor-data")
  |> range(start: -30m)
  |> filter(fn: (r) => r._measurement == "sensor_reading" and r._field == "temperature")
  |> aggregateWindow(every: 1m, fn: mean)
```

---

### Grafana — Dashboard

**Porta:** 3000 | **URL:** http://localhost:3000 | **Credenziali:** `admin` / `admin`

Legge i dati da InfluxDB e li visualizza in tempo reale. La dashboard e il datasource vengono caricati automaticamente all'avvio tramite il sistema di **provisioning** (cartella `grafana/provisioning/`) — nessuna configurazione manuale necessaria.

**Dashboard "Smart Park - Digital Twin" — pannelli:**

*Riga 1 — Stato attuale (ultimi 5 minuti):*
- Temperatura Media | Umidità Media | CO₂ Media | Persone nel Parco | Rumore Medio | Contatore Anomalie

*Riga 2 — Serie temporali per zona:*
- Temperatura per Zona | Umidità per Zona | CO₂ per Zona | Persone per Zona | Rumore per Zona | Tabella Anomalie

**Soglie di allerta visiva:**

| Metrica | Verde | Giallo | Rosso |
|---------|-------|--------|-------|
| Temperatura | < 25°C | 25–35°C | > 35°C |
| Umidità | 30–75% | > 75% | < 30% |
| CO₂ | < 600 ppm | 600–800 ppm | > 800 ppm |
| Persone | < 20 | 20–40 | > 40 |
| Rumore | < 60 dB | 60–75 dB | > 75 dB |
| Anomalie | 0 | — | ≥ 1 |

Aggiornamento automatico ogni 5 secondi. Finestra temporale default: ultimi 30 minuti.

---

### Eclipse Ditto — Digital Twin Engine

**Porta:** 8080 (tramite Nginx) | **Credenziali:** `ditto` / `ditto`

Mantiene una rappresentazione virtuale aggiornata di ogni sensore (il "Digital Twin"). A differenza di InfluxDB che conserva la serie storica, Ditto mantiene solo lo **stato corrente** di ogni sensore e lo espone tramite REST API e WebSocket.

È composto da 5 microservizi che formano un cluster distribuito (Pekko cluster):

| Microservizio | Ruolo |
|---------------|-------|
| `ditto-policies` | Gestisce le policy di accesso: chi può leggere/scrivere cosa sui Twin |
| `ditto-things` | Gestisce il ciclo di vita dei Digital Twin (creazione, aggiornamento, cancellazione) |
| `ditto-things-search` | Motore di ricerca e filtraggio sui Twin |
| `ditto-connectivity` | Gestisce connessioni esterne: si sottoscrive a MQTT e aggiorna i Twin ricevendo i messaggi dei sensori |
| `ditto-gateway` | Espone le API REST e WebSocket verso l'esterno |

#### Policy (`ditto/policies/smart-park-policy.json`)

Definisce i permessi di accesso ai Digital Twin. L'utente `nginx:ditto` (autenticato tramite Basic Auth su Nginx) ha accesso completo in lettura e scrittura a Things, Policies e Messaggi.

#### Things (`ditto/things/`)

Definiscono la struttura dei Digital Twin. Ogni file JSON descrive un sensore con i suoi attributi statici (nome, posizione, tipo) e le features dinamiche (misure aggiornate in tempo reale). Esempio struttura:

```json
{
  "thingId": "smart-park:sensor-entrance",
  "policyId": "smart-park:policy",
  "attributes": {
    "name": "Ingresso Principale",
    "location": { "lat": 38.1157, "lon": 13.3615 },
    "type": "environmental-sensor"
  },
  "features": {
    "temperature": { "properties": { "value": 21.5, "unit": "°C" } },
    "humidity":    { "properties": { "value": 58.4, "unit": "%" } },
    "airQuality":  { "properties": { "co2_ppm": 720.3, "status": "moderate" } },
    "motion":      { "properties": { "people_count": 12 } },
    "noise":       { "properties": { "value": 55.1, "unit": "dB" } },
    "status":      { "properties": { "last_update": "...", "anomaly": false } }
  }
}
```

#### Connessione MQTT (`ditto/connections/mqtt-connection.json`)

Configura il servizio Connectivity di Ditto per connettersi a Mosquitto e sottoscriversi ai topic `smart-park/+/telemetry`. Include uno **script JavaScript di mapping** che trasforma ogni payload MQTT nel formato Ditto Protocol per aggiornare le features del Twin corrispondente. La classificazione CO₂ avviene qui:
- `> 800 ppm` → `poor`
- `600–800 ppm` → `moderate`
- `< 600 ppm` → `good`

**API REST (Base URL: `http://localhost:8080/api/2` | Auth: `ditto:ditto`):**
```bash
# Lista tutti i Twin
GET /things

# Leggi un Twin specifico
GET /things/smart-park:sensor-entrance

# Leggi una singola feature
GET /things/smart-park:sensor-entrance/features/temperature

# Cerca Twin per attributo
GET /search/things?filter=eq(attributes/type,"environmental-sensor")
```

---

### MongoDB — Persistenza Ditto

**Porta:** 27017 | **Credenziali:** `ditto` / `ditto-secret`

Usato esclusivamente da Eclipse Ditto per persistere lo stato dei Digital Twin tra i riavvii. Non è accessibile direttamente dall'applicazione.

---

### Nginx — Reverse Proxy

**Porta:** 8080 (esposta all'host)

Si trova davanti a `ditto-gateway`. Ha due ruoli:
1. **Basic Auth** — verifica le credenziali dell'utente tramite `nginx.htpasswd`
2. **Pre-autenticazione Ditto** — passa l'utente autenticato a Ditto tramite l'header `x-ditto-pre-authenticated`, evitando una doppia autenticazione

Supporta anche WebSocket (necessario per le Ditto Live Messages).

---

### RabbitMQ — AMQP Broker

**Porta:** 5672 (AMQP) | 15672 (Management UI: http://localhost:15672)
**Credenziali Management UI:** `hono` / `hono-secret`

Infrastruttura interna di Eclipse Ditto. Il servizio Connectivity lo usa per la comunicazione tra i 5 microservizi del cluster Ditto. Non viene utilizzato direttamente dal codice applicativo.

---

### MQTT Explorer — Debug UI

**Porta:** 4000 | **URL:** http://localhost:4000

Interfaccia web per ispezionare in tempo reale i messaggi che transitano su Mosquitto. Utile per verificare che il simulatore stia pubblicando correttamente e per analizzare i payload.

Per connettersi all'interno della UI:
- Host: `mosquitto`
- Port: `1883`

---

### setup.sh

Script di inizializzazione da eseguire una sola volta al primo avvio del progetto. Genera automaticamente il file `nginx/nginx.htpasswd` con le credenziali hashate (usando `htpasswd` o `openssl`) e avvia lo stack Docker.

---

## Avvio del progetto

### Prerequisiti
- Docker Engine >= 28.x con Docker Compose plugin v2
- Python 3.12 con ambiente virtuale (`smart_park_env/`)
- Utente nel gruppo `docker` (`sudo usermod -aG docker $USER` + logout/login)

### 1. Avvia lo stack

```bash
cd ~/Desktop/smart_park_project
docker compose up -d
```

Attendi circa 2 minuti per la completa inizializzazione di Eclipse Ditto. Verifica lo stato:

```bash
docker compose ps
```

Tutti i servizi devono mostrare `Up (healthy)` o `Up`. Se un servizio Ditto risulta `unhealthy`, ferma e riavvia tutto:

```bash
docker compose down && docker compose up -d
```

### 2. Verifica lo stack

```bash
source smart_park_env/bin/activate
python3 scripts/test_stack.py
```

Tutti i test devono dare `PASS`.

### 3. Avvia il simulatore

```bash
source smart_park_env/bin/activate
python3 scripts/sensor_simulator.py
```

Premi `Ctrl+C` per fermarlo.

### 4. Visualizza i dati

Apri Grafana su http://localhost:3000 → Menu → Dashboards → **"Smart Park - Digital Twin"**

### Arresto

```bash
docker compose down
```

I dati nei volumi Docker (InfluxDB, MongoDB, Grafana) vengono preservati tra i riavvii.

---

## Credenziali

| Servizio | URL | Username | Password |
|----------|-----|----------|----------|
| Grafana | http://localhost:3000 | `admin` | `admin` |
| Eclipse Ditto API | http://localhost:8080 | `ditto` | `ditto` |
| Eclipse Ditto DevOps | http://localhost:8080 | `devops` | `devops` |
| RabbitMQ Management | http://localhost:15672 | `hono` | `hono-secret` |
| InfluxDB UI | http://localhost:8086 | `admin` | `admin-secret` |
| MQTT Explorer | http://localhost:4000 | — | — |
| MongoDB | localhost:27017 | `ditto` | `ditto-secret` |

---

## Struttura del progetto

```
smart_park_project/
│
├── docker-compose.yml                  # Orchestrazione dell'intero stack (13 servizi)
│
├── setup.sh                            # Script di inizializzazione (primo avvio)
│
├── mosquitto/
│   ├── config/
│   │   └── mosquitto.conf              # Configurazione broker MQTT (porte, persistenza, auth)
│   ├── data/                           # Persistenza messaggi MQTT (volume Docker)
│   └── log/                            # Log del broker
│
├── nginx/
│   ├── nginx.conf                      # Reverse proxy + Basic Auth + WebSocket verso Ditto
│   └── nginx.htpasswd                  # Credenziali utenti Ditto (hash APR1)
│
├── telegraf/
│   └── telegraf.conf                   # Bridge MQTT → InfluxDB (input/output plugin)
│
├── grafana/
│   └── provisioning/                   # Configurazione automatica al primo avvio
│       ├── datasources/
│       │   └── influxdb.yaml           # Connessione InfluxDB (Flux, token, bucket)
│       └── dashboards/
│           ├── dashboard.yaml          # Provider: dice a Grafana dove trovare i JSON
│           └── smart-park.json         # Dashboard completa con 15 pannelli
│
├── ditto/
│   ├── setup.sh                        # Script per creare policy, things e connection via API REST
│   ├── policies/
│   │   └── smart-park-policy.json      # Policy di accesso ai Digital Twin
│   ├── things/
│   │   ├── sensor-entrance.json        # Digital Twin — Ingresso Principale
│   │   ├── sensor-lake.json            # Digital Twin — Area Lago
│   │   └── sensor-playground.json      # Digital Twin — Area Giochi
│   └── connections/
│       └── mqtt-connection.json        # Connessione Ditto↔Mosquitto + mapping JavaScript
│
├── scripts/
│   ├── sensor_simulator.py             # Simulatore sensori (pubblica solo su MQTT)
│   ├── test_stack.py                   # Test suite completa per tutti i componenti
│   └── requirements.txt               # Dipendenze Python (paho-mqtt, influxdb-client, requests)
│
└── smart_park_env/                     # Ambiente virtuale Python (non committare)
    ├── bin/
    ├── include/
    ├── lib/
    └── lib64/
```
